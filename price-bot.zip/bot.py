import discord
from discord import app_commands
from discord.ext import commands
import json
import os
from flask import Flask
from threading import Thread

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

PRICES_FILE = "prices.json"

def load_prices():
    with open(PRICES_FILE, "r") as f:
        return json.load(f)

def save_prices(prices):
    with open(PRICES_FILE, "w") as f:
        json.dump(prices, f, indent=4)

@app_commands.describe(item="Item name", quantity="How many?")
@bot.tree.command(name="amount", description="Check the price of an item")
async def amount(interaction: discord.Interaction, item: str, quantity: int):
    prices = load_prices()
    item_key = item.lower().replace(" ", "_")
    if item_key in prices:
        total = prices[item_key] * quantity
        await interaction.response.send_message(f"Price for {quantity} {item}(s): £{total:.2f}")
    else:
        await interaction.response.send_message(f"Item '{item}' not found. Available: {', '.join(prices.keys())}")

@app_commands.describe(item="Item name", price="New price in GBP")
@bot.tree.command(name="setprice", description="Admins only: Set or change item price")
async def setprice(interaction: discord.Interaction, item: str, price: float):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ You must be an admin to use this.", ephemeral=True)
        return
    prices = load_prices()
    item_key = item.lower().replace(" ", "_")
    prices[item_key] = price
    save_prices(prices)
    await interaction.response.send_message(f"✅ Price for '{item}' set to £{price:.2f}")

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} command(s)")
    except Exception as e:
        print(e)

app = Flask('')
@app.route('/')
def home():
    return "I'm alive"

def run_web():
    app.run(host='0.0.0.0', port=8080)

Thread(target=run_web).start()

bot.run(os.getenv("DISCORD_TOKEN"))
